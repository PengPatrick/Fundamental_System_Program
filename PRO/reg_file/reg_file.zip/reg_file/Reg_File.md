# The Register File
# Author:
    Jingyu Peng (jp550)
# Design:
## Decoder
    I use the truth table to implement the 5 to 32 decoder
## 32 bit Register
    The register is composed of 32 dffe. The dffe implementation is provided.
## Tri-state buffer
    When selected bit is 1, output is the same as input; when selected bit is 0, output is 'z'

